import scrapy, os
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule
from ..items import ParcerocrawlerItem
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from .linkfinder import regex_str, parser_file
from .funciones import buscar_links_ocultos, filtrar_repetidos, get_form_details
from urllib.parse import urlparse
from colorama import just_fix_windows_console, Fore, Back, Style
import warnings
warnings.filterwarnings("ignore")
just_fix_windows_console()
dominiospermitidos = []


class ScannerSpider(scrapy.Spider):
    name = "scanner"
    paginasurl = []
    with open("./ParceroCrawler/spiders/dominios.txt") as archivo:
        for linea in archivo:
            dd = urlparse(linea)
            dominiospermitidos.append(dd.netloc)
            paginasurl.append(linea)
    allowed_domains = dominiospermitidos
    start_urls = paginasurl

    def start_requests(self):
        self.formularioencontrado = []
        self.linkencontrados = []
        for url1 in self.start_urls:
            yield scrapy.Request(url = url1, callback = self.parse, dont_filter = True)
            
            
    def parse(self, response):
        try:
            linkvisitados = []
            formulariovisitado = []
            quote_item = ParcerocrawlerItem()
            print(response.url)#response va a recibir el codigo devuelto por selenim
            urlcompleta = urlparse(response.url).scheme+"://"+urlparse(response.url).netloc
            #SACAMOS LOS LINKS DEL LOS JS
            extension = os.path.splitext(response.url)[1]
            # Comprueba si la extensión es .js
            if extension == ".js" or extension == ".json":
                endpoints = parser_file(response.text, regex_str, mode=0)
                for endpoint in endpoints:
                    if(urlparse(endpoint["link"]).netloc in dominiospermitidos or urlparse(endpoint["link"]).netloc == ""):
                        if(urlparse(endpoint["link"]).netloc == ""):
                            if(endpoint["link"][:1] == "/"):
                                if(urlcompleta+endpoint["link"] not in self.linkencontrados):
                                    self.linkencontrados.append(urlcompleta+endpoint["link"])
                                    linkvisitados.append(urlcompleta+endpoint["link"])
                            else:
                                if(urlcompleta+"/"+endpoint["link"] not in self.linkencontrados):
                                    self.linkencontrados.append(urlcompleta+"/"+endpoint["link"])
                                    linkvisitados.append(urlcompleta+"/"+endpoint["link"])
                        else:
                            if(endpoint["link"][:1] == "/"):
                                if(urlcompleta+endpoint["link"] not in self.linkencontrados):
                                    self.linkencontrados.append(urlcompleta+endpoint["link"])
                                    linkvisitados.append(urlcompleta+endpoint["link"])
                            else:
                                if(urlcompleta+"/"+endpoint["link"] not in self.linkencontrados):
                                    self.linkencontrados.append(urlcompleta+"/"+endpoint["link"])
                                    linkvisitados.append(urlcompleta+"/"+endpoint["link"])
                
                for dato in linkvisitados:
                    quote_item["url"] = dato
                    yield {"url": dato}
                    yield scrapy.Request(url = dato, callback = self.parse, dont_filter = True)
                                 
            else:
                # paginasocultas = buscar_links_ocultos(response.text)
                # print(paginasocultas)
                
                archi1=open("urls-js.txt","a+")
                soup = BeautifulSoup(response.text, 'html.parser')
                for link in soup.find_all('script'):
                    if(urlparse(link.get('src')).netloc in dominiospermitidos or urlparse(link.get('src')).netloc == ""):
                        if(urlparse(link.get('src')).netloc == ""):
                            if(urlcompleta+link.get('src') not in self.linkencontrados):
                                self.linkencontrados.append(urlcompleta+link.get('src'))
                                linkvisitados.append(urlcompleta+link.get('src'))
                                archi1.write(urlcompleta+link.get('src')+"\n")
                        else:
                            if(link.get('src') not in self.linkencontrados):
                                self.linkencontrados.append(link.get('src'))
                                linkvisitados.append(link.get('src'))
                                archi1.write(link.get('src')+"\n")
                archi1.close()


                forms = soup.find_all("form")# get all form tags
                inputsformulario = {}
                action = ""
                # iteratte over forms
                for i, form in enumerate(forms, start=1):
                    form_details = get_form_details(form)
                    print(Fore.BLUE +"="*50, f"form #{i}", "="*50+Fore.GREEN)
                    if(form_details["action"] != ""):
                        action = form_details["action"]
                    else:
                        action = urlparse(response.url).path
                    
                    if(form_details["method"] != ""):
                        method = form_details["method"]
                    else:
                        method = "GET"
                    
                    for inputsform in form_details["inputs"]:
                        if(inputsform["value"] != ""):
                            inputsformulario.update({inputsform["name"] : inputsform["value"]})
                        else:
                            inputsformulario.update({inputsform["name"] : "dada"})
                #for formularios in soup.find_all("form"):
                if(action not in self.formularioencontrado):
                    self.formularioencontrado.append(action)
                    if(action[:4] == "http"):
                        yield scrapy.FormRequest(action, callback=self.parse, formdata=inputsformulario)
                    else:
                        if(action[:1] == "/"):
                            yield scrapy.FormRequest(urlcompleta+action, callback=self.parse, formdata=inputsformulario)
                        else:
                            yield scrapy.FormRequest(urlcompleta+"/"+action, callback=self.parse, formdata=inputsformulario)

                link_extractor = LinkExtractor()
                links = link_extractor.extract_links(response)
                for link in links:
                    pagehost = urlparse(link.url)
                    if pagehost.netloc not in self.allowed_domains:
                        pass
                    else:    
                        if link.url not in self.linkencontrados:
                            self.linkencontrados.append(link.url)
                            linkvisitados.append(link.url)
                        
                linkfiltrados = []
                for testrepetidos in linkvisitados:
                    valor = filtrar_repetidos(testrepetidos, self.linkencontrados)
                    if(valor == True):
                        pass
                    else:
                        linkfiltrados.append(testrepetidos)

                archi1=open("urls.txt","a+")
                if(linkfiltrados != ""):
                    for dato in linkfiltrados:
                        quote_item["url"] = dato
                        yield {"url": dato}
                        extension3 = os.path.splitext(dato)[1]
                        if extension == ".js" or extension == ".json":
                            pass
                        else:
                            archi1.write(dato+"\n")
                            print(dato)
                        yield scrapy.Request(url = dato, callback = self.parse, dont_filter = True)
                archi1.close() 


        except:
            pass
