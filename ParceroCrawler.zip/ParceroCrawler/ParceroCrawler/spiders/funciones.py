import requests
import re
from urllib.parse import urlparse, parse_qs
import difflib


def buscar_links_ocultos(code):
    html = code

    # Buscar en los comentarios cualquier URL o path que pueda estar oculta
    urls_ocultas = re.findall(r"<!--.*?-->", html, re.DOTALL)
    urls_ocultas = [url for url in urls_ocultas if "http" in url]

    # Extraer las URLs y paths ocultos de los comentarios utilizando expresiones regulares
    urls_y_paths_ocultos = []
    for comentario in urls_ocultas:
        urls = re.findall(r"(https?://\S+)", comentario)
        paths = re.findall(r"(?<=/)\S+", comentario)
        urls_y_paths_ocultos += urls + paths

    return urls_y_paths_ocultos




def filtrar_repetidos(url1, url2):
    contadorrepetidos = 0
    for testurl2 in url2:
        differences = difflib.ndiff(url1, testurl2)

        differences = list(differences)

        # Cuenta el número de caracteres diferentes
        differences_count = sum(1 for d in differences if d[0] != ' ')

        # Determina si las URLs son parecidas
        if differences_count < 20:
           # print("Las URLs son parecidas")
            contadorrepetidos = contadorrepetidos + 1
            if(contadorrepetidos == 3):
                return True
                break



def get_form_details( form):
    """Devuelve los detalles HTML de un formulario,
        incluyendo acción, método y lista de controles de formulario (inputs, etc)"""
    details = {}
    action = form.attrs.get("action").lower()   # obtener la acción del formulario (requested URL)
                                                # get the form method (POST, GET, DELETE, etc)
                                                
    method = form.attrs.get("method", "get").lower()# si no se especifica, GET es el predeterminado en HTML
    
    inputs = []# get all form inputs
    for input_tag in form.find_all("input"):
        # get type of input form control
        input_type = input_tag.attrs.get("type", "text")
        # get name attribute
        input_name = input_tag.attrs.get("name")
        # get the default value of that input tag
        input_value =input_tag.attrs.get("value", "")
        # add everything to that list
        inputs.append({"type": input_type, "name": input_name, "value": input_value})



    ##Extraemos los select y textarea tambien
    for select in form.find_all("select"):
        # get the name attribute
        select_name = select.attrs.get("name")
        # set the type as select
        select_type = "select"
        select_options = []
        # the default select value
        select_default_value = ""
        # iterate over options and get the value of each
        for select_option in select.find_all("option"):
            # get the option value used to submit the form
            option_value = select_option.attrs.get("value")
            if option_value:
                select_options.append(option_value)
                if select_option.attrs.get("selected"):
                    # if 'selected' attribute is set, set this option as default    
                    select_default_value = option_value
        if not select_default_value and select_options:
            # if the default is not set, and there are options, take the first option as default
            select_default_value = select_options[0]
        # add the select to the inputs list
        inputs.append({"type": select_type, "name": select_name, "values": select_options, "value": select_default_value})
    for textarea in form.find_all("textarea"):
        # get the name attribute
        textarea_name = textarea.attrs.get("name")
        # set the type as textarea
        textarea_type = "textarea"
        # get the textarea value
        textarea_value = textarea.attrs.get("value", "")
        # add the textarea to the inputs list
        inputs.append({"type": textarea_type, "name": textarea_name, "value": textarea_value})

    # put everything to the resulting dictionary
    details["action"] = action
    details["method"] = method
    details["inputs"] = inputs
    return details